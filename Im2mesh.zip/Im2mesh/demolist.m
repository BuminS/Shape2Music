Examples
demo1.m - Demonstrate function im2meshBuiltIn, which use matlab built-in function generateMesh() to generate mesh from geometry.
demo2.m - Demonstrate function im2mesh, which use MESH2D to generate mesh from geometry.
demo3.m - Demonstrate how to export mesh as inp, bdf, and .node/.ele file.
demo4.m - Demonstrate what is inside function im2mesh.
demo5.m - Demonstrate the case of 'tolerance = eps'.
demo6.m and demo7.m - Demonstrate parameter 'tolerance'.
demo8.m - Demonstrate parameter 'tf_avoid_sharp_corner'.
demo9.m - Demonstrate parameter 'grad_limit'.
demo10.m - Demonstrate parameter 'select_phase'.