clc
clear all
close all
%%%%%%%%%%% Definitions %%%%%%%%%%

% 1st Purpose: Example for Generating 3rd Degree Bezier Curve

%%%% INPUT PARAMETERS %%%% 
% n --> Number of u values

% P0,P1,P2,P3 --> coordinates of control points

%%%% OUTPUT PARAMETERS %%%% 
%Plots of the curve

%%%%%%%%%%%%%%% SCRIPT %%%%%%%%%%%%
nelx=60;
nely=60;
h=40; %depth of the design

%Generating u values with increment of 
incr=.05;
% Open topology opt figure

open file_name.fig
figure(1);
hold on
axis([0 nelx 0 nely])
xlabel('x [mm]')
ylabel('y [mm]')
grid on

%%%%%%%%%%%%%%% Curve 1 %%%%%%%%%%%%
i=1; %ID of the curve
CVs(1,:,i)=[0,60,0];
CVs(2,:,i)=[1,60,0];
CVs(3,:,i)=[2,60,0];
CVs(4,:,i)=[3,60,0];

%%% Bezier Curve and Plot %%%
coords=BezierCurvePlot(i,CVs,incr)

%%%%%%%%%%%%%%% Curve 2 %%%%%%%%%%%%
i=2; %ID of the curve
CVs(1,:,i)=CVs(4,:,i); %bir oncekinin bittigi yer
CVs(2,:,i)=[12,45,0];
CVs(3,:,i)=[26,34,0];
CVs(4,:,i)=[33,29,0];

%%% Bezier Curve and Plot %%%
coords=BezierCurvePlot(i,CVs,incr)



%%%%%%%%%%%%%%% Curve 3 %%%%%%%%%%%%
i=3; %ID of the curve
k=1; %G1 continuity constant
CVs(1,:,i)=CVs(4,:,i-1);
CVs(2,:,i)=[((CVs(3,1,i-1)-CVs(4,1,i-1))/(-k))+CVs(1,1,i),((CVs(3,2,i-1)-CVs(4,2,i-1))/(-k))];
CVs(3,:,i)=[51,55,0];
CVs(4,:,i)=[48,60,0];

%%% Bezier Curve and Plot %%%
coords=BezierCurvePlot(i,CVs,incr)


%%%%%%%%%%%%%%% Curve 4 %%%%%%%%%%%%
i=4; %ID of the curve
CVs(1,:,i)=CVs(4,:,i-1);;
CVs(2,:,i)=[((CVs(3,1,i-1)-CVs(4,1,i-1))/(-k))+CVs(1,1,i),((CVs(3,2,i-1)-CVs(4,2,i-1))/(-k))];
CVs(3,:,i)=[51,55,0];
CVs(4,:,i)=[48,60,0];

%%% Bezier Curve and Plot %%%
coords=BezierCurvePlot(i,CVs,incr)


%%%%%%%%%%%%%%% Curve 5 %%%%%%%%%%%%

i=6; %ID of the curve
CVs(1,:,i)=CVs(4,:,i-1);;
CVs(2,:,i)=[47,60,0];
CVs(3,:,i)=[50,60,0];
CVs(4,:,i)=[51,60,0];

%%% Bezier Curve and Plot %%%
coords=BezierCurvePlot(i,CVs,incr)

%%%%%%%%%%%%%%% Curve 6 %%%%%%%%%%%%

i=6; %ID of the curve
CVs(1,:,i)=CVs(4,:,i-1);
CVs(2,:,i)=[54.5,53,0];
CVs(3,:,i)=[56.5,53,0];
CVs(4,:,i)=[58,60,0];

%%% Bezier Curve and Plot %%%
coords=BezierCurvePlot(i,CVs,incr)


%%%%%%%%%%%%%%% Curve 7 %%%%%%%%%%%%

i=7; %ID of the curve
CVs(1,:,i)=CVs(4,:,i-1);
CVs(2,:,i)=[54.5,53,0];
CVs(3,:,i)=[56.5,53,0];
CVs(4,:,i)=[58,60,0];

%%% Bezier Curve and Plot %%%
coords=BezierCurvePlot(i,CVs,incr)

%%%%%%%%%%%%%%% Curve 8 %%%%%%%%%%%%

i=8; %ID of the curve
CVs(1,:,i)=CVs(4,:,i-1);
CVs(2,:,i)=[54.5,53,0];
CVs(3,:,i)=[56.5,53,0];
CVs(4,:,i)=[58,60,0];

%%% Bezier Curve and Plot %%%
coords=BezierCurvePlot(i,CVs,incr)

%%%%%%%%%%%%%%% Curve 9 %%%%%%%%%%%%

i=9; %ID of the curve
CVs(1,:,i)=CVs(4,:,i-1);
CVs(2,:,i)=[((CVs(3,1,i-1)-CVs(4,1,i-1))/(-k))+CVs(1,1,i),((CVs(3,2,i-1)-CVs(4,2,i-1))/(-k))];
CVs(3,:,i)=[56.5,53,0];
CVs(4,:,i)=[58,60,0];

%%% Bezier Curve and Plot %%%
coords=BezierCurvePlot(i,CVs,incr)




